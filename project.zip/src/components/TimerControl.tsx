import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { getDatabase, ref, onValue, set } from 'firebase/database';
import app from '../firebase-config'; // Import firebase config

interface TimerControlProps {
  selectedHours: number;
  onTimerChange: (hours: number) => void;
  visible: boolean;
  onMotorsOn: () => void; // Function to turn on motors
}

export default function TimerControl({
  selectedHours,
  onTimerChange,
  visible,
  onMotorsOn,
}: TimerControlProps) {
  const [countdown, setCountdown] = useState<number>(selectedHours * 10); // Countdown in seconds
  const [isCounting, setIsCounting] = useState<boolean>(false);

  // Listen to Firebase timer node for countdown
  useEffect(() => {
    const db = getDatabase(app);
    const timerRef = ref(db, 'timer'); // Assuming "timer" node holds the countdown value

    const unsubscribe = onValue(timerRef, (snapshot) => {
      if (snapshot.exists()) {
        const firebaseCountdown = snapshot.val();
        setCountdown(firebaseCountdown); // Update countdown from Firebase
      }
    });

    return () => unsubscribe(); // Cleanup listener on unmount
  }, []);

  // Update countdown from dropdown selection
  useEffect(() => {
    setCountdown(selectedHours * 10); // Reset countdown when selected hours change
    // setIsCounting(false); // Stop counting until the user starts the countdown
  }, [selectedHours]);

  // Start the countdown
  useEffect(() => {
    if (isCounting && countdown > 0) {
      const intervalId = setInterval(() => {
        setCountdown((prev) => prev - 1);
        // Sync the countdown value back to Firebase
        const db = getDatabase(app);
        set(ref(db, 'timer'), countdown - 1); // Update Firebase "timer" node
      }, 1000);

      return () => clearInterval(intervalId); // Cleanup on unmount or when countdown stops
    }

    // When countdown hits zero, turn on the motors
    if (countdown === 0) {
      onMotorsOn();
      setIsCounting(false); // Stop the countdown
    }
  }, [countdown, isCounting, onMotorsOn]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 10);
    const mins = Math.floor((seconds % 10) / 60);
    const secs = seconds % 60;
    return `${hrs}:${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  if (!visible) return null;

  return (
    <div className="glass-card rounded-2xl shadow-xl p-6 mb-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-indigo-100 rounded-lg">
          <Clock className="w-6 h-6 text-indigo-600" />
        </div>
        <div className="flex items-center justify-between flex-grow ">
          <h3 className="text-lg font-medium text-gray-700">Timer Control</h3>
          <span className='text-gray-400'>
            <span className='text-gray-700 font-bold me-2'>{formatTime(countdown)}</span> 
            hours to turn on the motors
          </span>
        </div>
      </div>
      <div className="relative">
        <select
          value={selectedHours}
          onChange={(e) => {
            const newHours = Number(e.target.value);
            onTimerChange(newHours);
            setCountdown(newHours * 10); // Reset countdown to the new selected hours
            setIsCounting(true); // Start countdown when the dropdown changes
            // Sync the new selected hours with Firebase
            const db = getDatabase(app);
            set(ref(db, 'timer'), newHours * 10); // Update Firebase "timer" node
          }}
          className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl appearance-none cursor-pointer focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-300"
        >
          {Array.from({ length: 24 }, (_, i) => i + 1).map((hours) => (
            <option key={hours} value={hours}>
              {hours} {hours === 1 ? 'Hour' : 'Hours'}
            </option>
          ))}
        </select>
        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
          <div className="border-t-2 border-r-2 border-gray-400 w-2 h-2 transform rotate-45 translate-y-[-4px]"></div>
        </div>
      </div>
    </div>
  );
}
